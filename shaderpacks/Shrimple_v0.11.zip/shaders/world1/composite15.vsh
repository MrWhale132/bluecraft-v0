#version 430 compatibility

#define RENDER_TRANSLUCENT

#include "end.glsl"
#include "/program/composite15.vsh"
