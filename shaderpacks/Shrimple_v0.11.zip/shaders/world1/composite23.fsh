#version 430 compatibility

#include "end.glsl"
#include "/program/composite_bloom_down_3.fsh"
