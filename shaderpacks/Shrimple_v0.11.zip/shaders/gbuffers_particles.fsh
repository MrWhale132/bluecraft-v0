#version 430 compatibility

#define RENDER_OPAQUE

#include "overworld.glsl"
#include "/program/gbuffers_particles.fsh"
