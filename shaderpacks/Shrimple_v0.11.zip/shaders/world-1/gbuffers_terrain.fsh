#version 430 compatibility

#define RENDER_OPAQUE
#define RENDER_TERRAIN

#include "nether.glsl"
#include "/program/gbuffers_terrain.fsh"
