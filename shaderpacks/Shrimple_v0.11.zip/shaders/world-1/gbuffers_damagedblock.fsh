#version 430 compatibility

#define RENDER_OPAQUE

#include "nether.glsl"
#include "/program/gbuffers_damagedblock.fsh"
